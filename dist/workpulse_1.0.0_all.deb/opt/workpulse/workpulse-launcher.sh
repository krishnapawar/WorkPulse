#!/usr/bin/env bash
set -e

APP_DATA="$HOME/.workpulse"
mkdir -p "$APP_DATA"

# Seed default data.xlsx & settings if not present
if [ ! -f "$APP_DATA/settings.json" ]; then
    cp /opt/workpulse/settings.json "$APP_DATA/settings.json" 2>/dev/null || true
fi
if [ -f /opt/workpulse/data.xlsx ] && [ ! -f "$APP_DATA/data.xlsx" ]; then
    cp /opt/workpulse/data.xlsx "$APP_DATA/data.xlsx" 2>/dev/null || true
fi

cd "$APP_DATA"
exec python3 /opt/workpulse/app.py "$@"
